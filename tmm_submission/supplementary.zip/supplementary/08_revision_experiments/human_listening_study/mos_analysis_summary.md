# TTS 人工听测结果分析（2026-06-12，n=5 评测者 × 8 条目 × 4 系统 = 160 评分）

## 主结果（全部5人）

| System | MOS (1-5) | SD | Sim votes (40票) |
|---|---|---|---|
| GPT-SoVITS | 3.08 | 1.14 | **18 (45%)** |
| EdgeTTS | **3.12** | 1.14 | 0 (0%) |
| F5-TTS | 1.80 | 1.02 | 6 (15%) |
| CosyVoice2 | 1.52 | 0.88 | 2 (5%) |
| (どれも似ていない) | — | — | 14 (35%) |

## 显著性检验（Wilcoxon signed-rank, paired by rater×item, n=40）

- GPT-SoVITS vs EdgeTTS: Δ=-0.05, z=-0.09, **p=0.926（无显著差异，统计上持平）**
- GPT-SoVITS vs F5-TTS: Δ=+1.27, z=4.13, **p<0.0001**
- GPT-SoVITS vs CosyVoice2: Δ=+1.55, z=4.62, **p<0.0001**

## 评测者间一致性

- ICC(2,1) 单一度量 = 0.295（中低）
- ICC(2,k) 平均度量 = 0.676（中等偏好，MOS 面板常报此项）
- Krippendorff's α (ordinal) = 0.312

## 关键叙事（论文用）

1. **自然度**：GPT-SoVITS 与商用 EdgeTTS 统计持平（p=0.93），二者均显著优于
   F5-TTS 和 CosyVoice2（p<0.0001）。
2. **话者相似度**：GPT-SoVITS 压倒性领先（45% 票），EdgeTTS 因固定音色
   得 0 票——证实其无法用于需要保留说话人音色的配音场景。
3. **结论**：GPT-SoVITS 是唯一同时具备高自然度和声音克隆能力的系统，
   人工评测与自动指标（最低 WER 1.17）一致 → 支持论文选型。
4. 35% "都不像" 票反映短参考音频跨语言克隆的难度，作为 limitation 讨论。

## 评测者明细

| Rater | JP Level | Overall mean | 备注 |
|---|---|---|---|
| R1 | N1 | 2.88 | GPT-SoVITS 最高 4.12 |
| R3 | N1 | 2.53 | F5-TTS 偏好者 (3.12) |
| R2 | N1 | 2.06 | |
| R5 | N1 | 2.16 | |
| R4 | N1 | 2.28 | EdgeTTS 全5分异常模式 |

敏感性分析：排除 EdgeTTS-全5分评测者后 GPT-SoVITS 自然度第一
（3.31 vs 2.66, p=0.008），但论文报全部5人数据（不挑选）。

## 数据文件

- 原始数据: `human_eval/mos_results_raw.csv`（160行）
- Backend survey data were collected via a self-hosted dashboard; admin credentials are withheld and not part of this release.
