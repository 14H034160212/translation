# 08 — Revision Experiments (second-round TMM revision)

Artifacts for the experiments added during the second-round revision. All
numbers here match the corresponding tables/sections in the manuscript.

## finetuning_scaling/
LoRA fine-tuning scaling study (Table: Subtitle Translation Results, Per-fold BLEU).
- `gemma4_12b_ft_fold{0-4}.json` — Gemma-4-12B LoRA FT, per-fold held-out outputs
  (text-only, r=16, alpha=32, lr=1e-4, 15 epochs, patience 5). Per-fold BLEU
  [30.00, 30.11, 28.69, 31.40, 33.55] → 30.75 ± 1.84.
- `gemma4_12b_ft_comet_summary.json` — per-fold COMET → 0.890 ± 0.010.
- `qwen3vl_multimodal_ft_fold{0-4}.json` — Qwen3-VL-4B FT with 4 video frames
  per episode (r=32, alpha=64, lr=5e-5, 20 epochs). Per-fold BLEU
  [18.51, 19.78, 7.12, 10.35, 22.16] → 15.58 ± 6.49 (vs text-only FT 15.70 ± 4.42;
  paired t = -0.04, p = 0.97 → visual frames do not help fine-tuning).
- `qwen3vl_multimodal_ft_comet_summary.json` — per-fold COMET → 0.846 ± 0.039.
Each fold JSON contains {fold, n_val, BLEU, chrF++, results:[{id, source,
reference, prediction}]}.

## tts_reevaluation/
- `tts_reeval_mecab.json` — TTS intelligibility recomputed with Whisper-medium,
  NFKC + punctuation stripping, character-level CER and MeCab-tokenised WER
  (Table: TTS evaluation). Per-utterance rows + per-system means.
- `static_vs_adaptive_unified.json` — fusion gating ablation under a single
  unified harness (Table: gating-rule ablation): the adaptive log-probability
  gate ties the best static similarity threshold (composite 0.8091 vs 0.8094).

## human_listening_study/
Blind listening study (Table: Human listening study results).
- `mos_results_raw.csv` — raw ratings: session_id, rater_name, jp_level,
  age_group, submitted_at, item, code, naturalness, similarity.
- `mos_analysis_summary.md` — per-system MOS / similarity, Wilcoxon tests,
  ICC(2,1)/ICC(2,k), Krippendorff's alpha.
- `manifest_rater{1-5}.json` — per-rater blind A/B/C/D → system mappings
  (randomised presentation order). Kept private from raters during the study.

## scripts/
Exact scripts used to produce the above:
- `train_eval_gemma4_12b_lora.py`, `train_eval_qwen3vl_multimodal_ft.py`
- `reeval_tts_wer_cer.py`, `run_static_vs_adaptive.py`
- `aggregate_pilot_folds.py`, `compute_comet_pilots.py`

## Note on tooling
The authors used a generative-AI assistant to accelerate experiment scripting
and analysis; all methodological choices, results, and verification are the
authors' own.
