# Composite Recognition Score (Eq. 1 of the manuscript)

For a recognition system producing hypothesis subtitles against gold references, we report

$$\text{Composite} \;=\; \frac{(1 - \text{CER}) \;+\; \text{CharAcc} \;+\; \frac{\text{BLEU}}{100} \;+\; \frac{\text{chrF++}}{100}}{4}$$

where:

| Term            | Range  | Direction | Source                       |
|-----------------|--------|-----------|------------------------------|
| `1 - CER`       | [0, 1] | ↑         | jiwer CER on Japanese chars  |
| `CharAcc`       | [0, 1] | ↑         | exact character match rate   |
| `BLEU / 100`    | [0, 1] | ↑         | SacreBLEU `13a`              |
| `chrF++ / 100`  | [0, 1] | ↑         | SacreBLEU chrF++             |

All four sub-scores are clipped to `[0, 1]`, so the composite score is also in `[0, 1]`.
The composite is intentionally **simple and unweighted** so that no single metric can dominate the rank ordering; small differences in any one metric still translate to small differences in the composite.

Implementation:
```python
def composite(cer, char_acc, bleu, chrf):
    parts = [max(0.0, 1.0 - cer), char_acc, bleu / 100.0, chrf / 100.0]
    parts = [min(1.0, max(0.0, p)) for p in parts]
    return sum(parts) / 4.0
```
