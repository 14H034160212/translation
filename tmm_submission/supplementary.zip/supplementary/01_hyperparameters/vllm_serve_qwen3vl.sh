#!/usr/bin/env bash
# vLLM launch script for Qwen3-VL-4B used as the OCR backbone (Section 5.3, 5.10).
# Tested with vllm==0.6.4 on a single NVIDIA RTX 3090 (24 GB).

set -euo pipefail

MODEL=${MODEL:-"Qwen/Qwen3-VL-4B-Instruct"}
PORT=${PORT:-8000}
HOST=${HOST:-"0.0.0.0"}

# --max-model-len trimmed to keep KV cache within 24 GB at 5 fps batched OCR.
# --gpu-memory-utilization 0.85 leaves headroom for other co-resident jobs.
# --max-num-seqs sized for 5 fps of a 90 s clip = 450 frames per batch.

vllm serve "${MODEL}" \
  --host "${HOST}" --port "${PORT}" \
  --dtype bfloat16 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.85 \
  --max-num-seqs 64 \
  --trust-remote-code \
  --limit-mm-per-prompt image=1 \
  --served-model-name qwen3vl-4b
