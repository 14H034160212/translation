# Supplementary Materials

**Manuscript:** *End-to-End Subtitle Recognition & Chinese–Japanese Translation with Speech Synthesis in Short Dramas*

This archive accompanies the ACM TOMM submission. It is intended to (a) document every hyperparameter, prompt, and evaluation tool exactly as used to produce the numbers in the paper, and (b) provide qualitative samples that cannot be conveyed by metrics alone. The underlying video, audio, and subtitle corpus is **not** redistributed here, in compliance with the research-use agreement with the data provider; only redacted metadata, configurations, and short content-neutral examples are included.

---

## Contents

```
supplementary/
├── README.md                          (this file)
├── 01_hyperparameters/
│   ├── lora_qwen3vl_4b.yaml           LoRA config for Qwen3-VL-4B (primary translator, text-only)
│   ├── lora_qwen3_8b.yaml             LoRA config for Qwen3-8B FT (text-only)
│   ├── lora_qwen25_3b.yaml            5-fold CV LoRA config for Qwen2.5-3B baseline
│   ├── whisper_decoding.json          Whisper-medium decoding parameters
│   └── vllm_serve_qwen3vl.sh          vLLM launch command for OCR serving
├── 02_prompts/
│   ├── ocr_prompt.txt                 Frame-level OCR prompt (Qwen3-VL)
│   ├── translation_prompt_zs.txt      Zero-shot Chinese→Japanese prompt
│   └── translation_prompt_ft.txt      Fine-tuned model instruction template
├── 03_evaluation/
│   ├── sacrebleu_signature.txt        Exact SacreBLEU signature used for all BLEU/chrF++
│   ├── comet_checkpoint.txt           COMET checkpoint identifier and version
│   ├── jiwer_config.json              jiwer normalization rules for WER/CER
│   └── composite_score_definition.md  Composite recognition score definition (Eq. 1)
├── 04_per_episode_metrics/
│   ├── translation_per_episode.csv    BLEU/chrF++/COMET per validation episode
│   ├── recognition_per_episode.csv    CER/CharAcc/BLEU per episode for each model
│   └── tts_per_speaker.csv            WER/CER per speaker for each TTS system
├── 05_qualitative_examples/
│   ├── translation_pairs.tsv          50 anonymized Chinese→Japanese translation pairs
│   │                                  (gold + zero-shot + fine-tuned outputs)
│   ├── ocr_vs_asr_corrections.tsv     30 examples where adaptive fusion corrected ASR
│   └── synthesis_samples/             5 short content-neutral synthesized clips (.wav)
├── 06_dataset_metadata/
│   ├── episode_statistics.csv         Per-episode duration, segment count, char count
│   ├── fold_assignments.csv           5-fold CV split (episode_id → fold_id)
│   └── speaker_inventory.csv          12 speaker IDs with reference-clip durations
├── 07_compute/
│   └── runtime_profile.csv            Per-stage RTF on RTX 3090 (matches Section 5.10)
└── 08_revision_experiments/          Second-round revision artifacts (see its own README)
    ├── finetuning_scaling/           Gemma-4-12B FT & Qwen3-VL multimodal FT (5-fold + COMET)
    ├── tts_reevaluation/             Recomputed TTS CER/WER (mecab) + unified fusion ablation
    ├── human_listening_study/        MOS raw ratings, analysis, per-rater blind manifests
    └── scripts/                      Exact scripts for the above
```

---

## How to reproduce the reported numbers

The pipeline is run end-to-end on a single NVIDIA RTX 3090 (24 GB VRAM), Ubuntu 22.04, Python 3.10. The relevant version pins are listed in `01_hyperparameters/`. Provided you have access to the source video files under the same `episode_id` naming convention given in `06_dataset_metadata/episode_statistics.csv`, the pipeline executes in four stages:

### Stage 1 — Subtitle Recognition

```bash
# (a) ASR with Whisper-medium (config: 03_evaluation/whisper_config — same as released model)
python scripts/run_whisper.py \
    --model medium --language zh \
    --audio_dir /path/to/audio --out asr_outputs/

# (b) Frame-level OCR with Qwen3-VL-4B served via vLLM (5 fps for production)
bash 01_hyperparameters/vllm_serve_qwen3vl.sh
python scripts/run_ocr.py \
    --fps 5 --prompt 02_prompts/ocr_prompt.txt \
    --frame_dir /path/to/frames --out ocr_outputs/
```

### Stage 2 — Confidence-Adaptive Fusion

```bash
python scripts/fuse.py \
    --whisper asr_outputs/ --ocr ocr_outputs/ \
    --p_threshold -0.5 --s_threshold 0.6 --window 1.5 \
    --out fused_subs/
```

`--p_threshold` and `--s_threshold` correspond to $\theta_p$ and $\theta_s$ in Algorithm 1 of the paper.

### Stage 3 — Translation (LoRA fine-tuning + inference)

```bash
# Train fold-0 (one fold of the 5-fold CV; see Subtitle Translation Results table)
python scripts/train_lora.py --config 01_hyperparameters/lora_qwen3vl_4b.yaml --fold 0

# Inference on validation episodes (the same fold)
python scripts/translate.py \
    --adapter checkpoints/qwen3vl_4b_fold0/ \
    --prompt 02_prompts/translation_prompt_ft.txt \
    --in fused_subs/ --out translated/
```

### Stage 4 — Speech Synthesis

```bash
python scripts/tts_gptsovits.py \
    --refs 06_dataset_metadata/speaker_inventory.csv \
    --in translated/ --out synth_audio/
```

Final evaluation:

```bash
python scripts/eval_translation.py --hyp translated/ --ref gold_jp/ \
    --comet wmt22-comet-da --bleu sacrebleu
python scripts/eval_tts.py --audio synth_audio/ --ref translated/ --asr whisper-medium
```

`scripts/` is shipped together with the source-code release referenced in the *Reproducibility Statement* of the paper; the configurations in this archive are the inputs to those scripts.

---

## Notes on each subdirectory

### 01_hyperparameters/
The LoRA YAMLs are the exact PEFT configs used. `lora_qwen3vl_4b.yaml` (primary, text-only) uses rank `r=32`, `α=64`, applied to `q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj`, max 20 epochs with patience 3, lr `5e-5`, per-device batch 1, gradient accumulation 4 (effective batch 4). `lora_qwen3_8b.yaml` documents the text-only Qwen3-8B FT (r=16, α=32, lr `1e-4`, 15 epochs, patience 5). The Gemma-4-12B FT pilot reuses the latter schedule (see `08_revision_experiments/scripts/`).

### 02_prompts/
Verbatim prompts. The OCR prompt explicitly forbids non-subtitle text and instructs `"No subtitles"` as the empty-frame fallback. The fine-tuned translation prompt assumes the LoRA adapter has been merged.

### 03_evaluation/
SacreBLEU is invoked with `nrefs:1|case:mixed|tok:13a|smooth:exp|version:2.4.0`. COMET is `Unbabel/wmt22-comet-da` revision pinned in `comet_checkpoint.txt`. jiwer normalization applies Unicode NFC, lowercase folding, and removes ASCII punctuation only — not Japanese punctuation — to avoid inflating CER.

### 04_per_episode_metrics/
These CSVs let reviewers compute their own confidence intervals on the 79-episode dataset. Mean ± 95% bootstrap CI for the headline numbers:

| Metric                       | Mean (5-fold) | Std    |
|------------------------------|---------------|--------|
| Qwen3-VL-4B FT BLEU          | 15.70         | ±4.42  |
| Qwen3-VL-4B FT chrF++        | 20.78         | ±2.81  |
| Qwen3-VL-4B FT COMET         | 0.843         | ±0.026 |
| Qwen3-8B FT BLEU             | 19.69         | ±2.49  |
| Gemma-4-12B FT BLEU          | 30.75         | ±1.84  |
| Adaptive fusion composite    | 0.810         | —      |

Computed via 10,000 nonparametric bootstrap resamples over episodes (validation fold).

### 05_qualitative_examples/
- `translation_pairs.tsv`: each row is `episode_id\tchinese\tgold_japanese\tzs_japanese\tft_japanese`. Names are replaced with `[Person_A]` etc. to avoid leaking series identity.
- `ocr_vs_asr_corrections.tsv`: each row shows a Whisper hypothesis, the chosen OCR substitution, and the ground-truth subtitle for the same time window — illustrating the four error categories from the qualitative analysis.
- `synthesis_samples/`: five short (≤6 s) synthesized clips, each containing a content-neutral line (greetings, weather, etc.). The corresponding text and the TTS engine used are listed in `synthesis_samples/manifest.csv`. **No actor-identifiable utterances are released.**

### 06_dataset_metadata/
Sufficient statistics to reconstruct the experimental protocol on any compatible source corpus.

### 07_compute/
Per-stage real-time factors for the profiling reported in Section 5.10, plus per-stage GPU memory peaks.

---

## Contact

Questions about this supplementary archive should be addressed to the corresponding author listed in the manuscript.
